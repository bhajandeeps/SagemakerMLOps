# Importing required library
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
# you can put any value here according to your situation
chunksize = 10000
from sklearn import preprocessing
import glob
import uuid
import time
import datetime
runtime=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
unqstr=datetime.datetime.now().strftime("%Y%m%d%H%M%S")
path = r'/opt/ml/processing/input' # Input path
all_files = glob.glob(path + "/*.csv")
#read them into pandas
filname=all_files[0].split('/')[-1]
filname=filname.split('.')[0]
df_list = [pd.read_csv(filename,nrows=100000) for filename in all_files]
data = pd.concat(df_list)
df = data.copy()
df.drop(columns=['Unnamed: 0','url', 'region', 'region_url', 'VIN', 'size', 'image_url', 'description', 'state', 'lat', 'long','posting_date'], inplace=True)
imr = SimpleImputer(strategy='mean')
imr = imr.fit(df[['odometer']])
imputed_data = imr.transform(df[['odometer']])
df['odometer'] = pd.DataFrame(imputed_data)
def encode_features(dataframe):
    result = dataframe.copy()
    encoders = {}
    for column in result.columns:
        if column in ['year','odometer','id','scorefilename']:
            result[column]=result[column]
            
        elif result.dtypes[column] == np.object:
            encoders[column] = preprocessing.LabelEncoder()
            result[column] = encoders[column].fit_transform(result[column])
    return result, encoders
encoded_df, encoders = encode_features(df.astype(str)) 
encoded_df=encoded_df[encoded_df['year']!='nan']
encoded_df['runtime']=runtime
encoded_df['modelname']='XGboost'
encoded_df['infertype']='Batch'
encoded_df['id']=df.id.apply(lambda x:str(x)+unqstr)
encoded_df.insert(0,'runtime',encoded_df.pop('runtime'))
encoded_df.insert(1,'modelname',encoded_df.pop('modelname'))
encoded_df.insert(2,'infertype',encoded_df.pop('infertype'))
encoded_df.insert(3,'id',encoded_df.pop('id'))
encoded_df.insert(4,'scorefilename',encoded_df.pop('scorefilename'))
encoded_df.to_csv("/opt/ml/processing/output/test/"+filname+"_{}.csv".format(uuid.uuid1().time_low), index=False, header=False) # test data 
